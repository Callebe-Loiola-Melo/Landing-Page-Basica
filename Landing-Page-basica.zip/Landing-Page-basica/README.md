# Estilo-de-Landing-Page-Básica

Este projeto é uma landing page básica desenvolvido para uma profissional da área de estética. O objetivo é apresentar seus serviços, aumentar sua presença online e facilitar o contato com clientes por meio de um design moderno, responsivo e focado na conversão.

⚠️ Atenção:
Se você apenas baixar os arquivos, o site pode não funcionar corretamente.
Isso acontece porque todas as imagens foram organizadas em uma pasta chamada img, e o GitHub não faz upload de pastas.
